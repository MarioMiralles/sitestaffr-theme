<?php
/**
 * Widget module loader for SiteStaffr public handlers.
 *
 * @package SiteStaffr
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Widget token AJAX handler module.
 */
require_once SITESTAFFR_PLUGIN_DIR . 'public/modules/class-sitestaffr-widget-token-handler.php';

/**
 * Widget WebRTC session AJAX handler module.
 */
require_once SITESTAFFR_PLUGIN_DIR . 'public/modules/class-sitestaffr-widget-webrtc-session-handler.php';

/**
 * Widget realtime session AJAX handler module.
 */
require_once SITESTAFFR_PLUGIN_DIR . 'public/modules/class-sitestaffr-widget-realtime-session-handler.php';

/**
 * Widget finalize usage AJAX handler module.
 */
require_once SITESTAFFR_PLUGIN_DIR . 'public/modules/class-sitestaffr-widget-finalize-usage-handler.php';

/**
 * Widget render handler module.
 */
require_once SITESTAFFR_PLUGIN_DIR . 'public/modules/class-sitestaffr-widget-render-handler.php';

/**
 * Widget auto-display handler module.
 */
require_once SITESTAFFR_PLUGIN_DIR . 'public/modules/class-sitestaffr-widget-auto-display-handler.php';

/**
 * Widget rendered-state handler module.
 */
require_once SITESTAFFR_PLUGIN_DIR . 'public/modules/class-sitestaffr-widget-is-rendered-handler.php';

/**
 * Widget settings provider module.
 */
require_once SITESTAFFR_PLUGIN_DIR . 'public/modules/class-sitestaffr-widget-settings-provider.php';
