<?php
/**
 * Rendered-state handler module for SiteStaffr widget.
 *
 * @package SiteStaffr
 */

class SiteStaffr_Widget_Is_Rendered_Handler {

	/**
	 * Return the widget rendered state.
	 *
	 * @since 0.14.262
	 * @param bool $rendered Whether widget has been rendered.
	 * @return bool
	 */
	public static function is_rendered( $rendered ) {
		return $rendered;
	}
}
