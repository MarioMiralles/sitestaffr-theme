<?php
/**
 * Widget settings provider for SiteStaffr widget modules.
 *
 * @package SiteStaffr
 */

class SiteStaffr_Widget_Settings_Provider {

	/**
	 * Get fixed widget settings from options.
	 *
	 * @return array
	 */
	public static function get_widget_settings() {
		return get_option( 'sitestaffr_widget_settings', array() );
	}
}
