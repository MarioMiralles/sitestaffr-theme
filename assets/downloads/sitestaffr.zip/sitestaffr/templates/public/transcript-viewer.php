<?php
/**
 * Public Transcript Viewer Template
 *
 * Standalone HTML page for viewing call transcripts via magic link.
 * Renders outside wp-admin with no WordPress chrome.
 *
 * Variables available (set by SiteStaffr_Transcript_Viewer):
 *   $call               - Call record object
 *   $sitestaffr_transcripts         - Array of transcript message objects
 *   $formatted_date      - Formatted date string (e.g. "March 6, 2026 2:30 PM EST")
 *   $formatted_duration  - Formatted duration string (e.g. "2:05")
 *   $business_name       - Business name from settings
 *   $summary_data        - Array with: visitor_name, phone, email, reason, followup, summary_text
 *   $ai_followup         - AI follow-up text from call record
 *   $logo_url            - URL to SiteStaffr logo
 *
 * @since      1.2.0
 * @package    SiteStaffr
 * @subpackage SiteStaffr/templates/public
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load shared recap formatter for full AI summary rendering.
require_once SITESTAFFR_PLUGIN_DIR . 'includes/sitestaffr-format-recap.php';

// Page title.
$sitestaffr_page_title = ! empty( $business_name )
	? $business_name . ' — Conversation Transcript'
	: 'Conversation Transcript';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="robots" content="noindex, nofollow">
	<title><?php echo esc_html( $sitestaffr_page_title ); ?></title>
	<?php wp_head(); ?>
</head>
<body>

	<!-- Top Bar (contained) -->
	<div class="sitestaffr-tv-topbar">
		<div class="sitestaffr-tv-topbar-inner">
			<img src="<?php echo esc_url( $logo_url ); ?>" alt="SiteStaffr">
			<button onclick="window.print()" class="sitestaffr-tv-print-btn">Print / Download PDF</button>
		</div>
	</div>

	<div class="sitestaffr-tv-container">

		<!-- Business Name Header -->
		<?php if ( ! empty( $business_name ) ) : ?>
			<div class="sitestaffr-tv-biz-header">
				<h1><?php echo esc_html( $business_name ); ?></h1>
			</div>
		<?php endif; ?>

		<!-- Conversation Recap Card -->
		<div class="sitestaffr-tv-card">
			<div class="sitestaffr-tv-card-header">
				<h2>Conversation Recap</h2>
				<?php if ( ! empty( $formatted_date ) ) : ?>
					<span class="sitestaffr-tv-card-meta"><?php echo esc_html( $formatted_date ); ?></span>
				<?php endif; ?>
			</div>
			<div class="sitestaffr-tv-card-body">
				<?php if ( ! empty( $call->ai_summary ) ) : ?>
					<div class="sitestaffr-tv-recap-body">
						<?php echo wp_kses_post( sitestaffr_format_recap_html( $call->ai_summary, true ) ); ?>
					</div>
				<?php else : ?>
					<p class="sitestaffr-tv-empty">Conversation recap not yet generated.</p>
				<?php endif; ?>
			</div>
		</div>

		<!-- Conversation Transcript Card -->
		<div class="sitestaffr-tv-card">
			<div class="sitestaffr-tv-card-header">
				<h2>Conversation Transcript</h2>
				<?php if ( ! empty( $formatted_duration ) ) : ?>
					<span class="sitestaffr-tv-card-meta"><?php echo esc_html( $formatted_duration ); ?></span>
				<?php endif; ?>
			</div>
			<div class="sitestaffr-tv-card-body">
				<?php if ( empty( $sitestaffr_transcripts ) ) : ?>
					<p class="sitestaffr-tv-empty">No transcript available for this conversation.</p>
				<?php else : ?>
					<div class="sitestaffr-tv-transcript">
						<?php
						$sitestaffr_eastern = new DateTimeZone( 'America/New_York' );
						foreach ( $sitestaffr_transcripts as $sitestaffr_transcript ) :
							$sitestaffr_is_visitor    = ( 'caller' === $sitestaffr_transcript->speaker );
							$sitestaffr_speaker_label = $sitestaffr_is_visitor ? 'Visitor' : 'AI';
							$sitestaffr_msg_time      = '';

							if ( ! empty( $sitestaffr_transcript->timestamp ) ) {
								try {
									$sitestaffr_msg_dt = new DateTime( $sitestaffr_transcript->timestamp, new DateTimeZone( 'UTC' ) );
									$sitestaffr_msg_dt->setTimezone( $sitestaffr_eastern );
									$sitestaffr_msg_time = $sitestaffr_msg_dt->format( 'g:i:s A' );
								} catch ( Exception $e ) {
									$sitestaffr_msg_time = '';
								}
							}
						?>
							<div class="sitestaffr-tv-item">
								<?php if ( $sitestaffr_is_visitor ) : ?>
									<div class="sitestaffr-tv-avatar">
										<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M10 0a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 3.33a3.33 3.33 0 1 1 0 6.67 3.33 3.33 0 0 1 0-6.67zm0 14.34a7.33 7.33 0 0 1-5.67-2.67c.03-1.88 3.78-2.92 5.67-2.92s5.64 1.04 5.67 2.92A7.33 7.33 0 0 1 10 17.67z"/></svg>
									</div>
								<?php endif; ?>
								<div class="sitestaffr-tv-bubble <?php echo esc_attr( $sitestaffr_is_visitor ? 'sitestaffr-tv-bubble-visitor' : 'sitestaffr-tv-bubble-ai' ); ?>">
									<div class="sitestaffr-tv-bubble-head">
										<span class="sitestaffr-tv-bubble-speaker <?php echo esc_attr( $sitestaffr_is_visitor ? 'sitestaffr-tv-bubble-speaker-visitor' : 'sitestaffr-tv-bubble-speaker-ai' ); ?>">
											<?php echo esc_html( $sitestaffr_speaker_label ); ?>
										</span>
										<?php if ( ! empty( $sitestaffr_msg_time ) ) : ?>
											<span class="sitestaffr-tv-bubble-time"><?php echo esc_html( $sitestaffr_msg_time ); ?></span>
										<?php endif; ?>
									</div>
									<p class="sitestaffr-tv-bubble-text"><?php echo esc_html( stripslashes( $sitestaffr_transcript->message_text ) ); ?></p>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>

	</div>

	<!-- Footer -->
	<div class="sitestaffr-tv-footer">
		Powered by <a href="https://sitestaffr.com" target="_blank" rel="noopener noreferrer">SiteStaffr</a> &mdash; AI Voice Assistant for WordPress
	</div>

</body>
</html>
