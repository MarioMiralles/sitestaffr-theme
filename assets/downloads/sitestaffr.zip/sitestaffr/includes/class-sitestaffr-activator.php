<?php
/**
 * Fired during plugin activation.
 *
 * @link       https://github.com/sitestaffr/sitestaffr-plugin
 * @since      1.0.0
 *
 * @package    SiteStaffr
 * @subpackage SiteStaffr/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    SiteStaffr
 * @subpackage SiteStaffr/includes
 * @author     SiteStaffr
 */
class SiteStaffr_Activator {

    /**
     * Activate the plugin.
     *
     * Creates necessary database tables and sets default options.
     *
     * @since    1.0.0
     */
    public static function activate() {
        // Load database class
        require_once SITESTAFFR_PLUGIN_DIR . 'includes/class-sitestaffr-database.php';

        // Create database tables
        SiteStaffr_Database::create_tables();

        // Set default options
        add_option( 'sitestaffr_version', SITESTAFFR_VERSION );

        // Set middleware URL if not already configured
        add_option( 'sitestaffr_middleware_url', 'https://sitestaffr-middleware-375589245036.us-central1.run.app' );

        // SECURITY: Generate API secret for middleware authentication if not exists
        $api_secret = get_option( 'sitestaffr_api_secret' );
        if ( empty( $api_secret ) ) {
            // Generate cryptographically secure random secret (64 hex characters = 32 bytes)
            $api_secret = bin2hex( random_bytes( 32 ) );
            update_option( 'sitestaffr_api_secret', $api_secret );
            SiteStaffr_Logger::legacy( 'SiteStaffr Activator: Generated new API secret for middleware authentication' );
        }

        // Create local identity only; defer network registration until setup is completed.
        // Compliance: avoid activation-time "phone-home" before explicit admin onboarding.
        if ( class_exists( 'SiteStaffr_Site_Registration' ) ) {
            SiteStaffr_Site_Registration::get_or_create_installation_id();
        } else {
            SiteStaffr_Logger::legacy( 'SiteStaffr Activator: Site registration class not loaded, identity initialization skipped' );
        }

        // Set activation redirect transient (first activation only).
        if ( ! get_option( 'sitestaffr_activation_redirect_done', false ) ) {
            set_transient( 'sitestaffr_activation_redirect', true, 30 );
        }

        // Flush rewrite rules
        flush_rewrite_rules();
    }
}
