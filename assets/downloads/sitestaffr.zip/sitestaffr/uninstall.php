<?php
/**
 * Uninstall routine for SiteStaffr.
 *
 * Data is intentionally preserved on uninstall.
 * Billing is intentionally NOT auto-canceled; customers manage subscriptions
 * through Stripe Customer Portal.
 *
 * @package SiteStaffr
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// No additional uninstall cleanup required.
