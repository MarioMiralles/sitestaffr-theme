<?php
/**
 * Call lifecycle AJAX handlers for SiteStaffr admin.
 *
 * @package    SiteStaffr
 * @subpackage SiteStaffr/admin/traits
 * @since      0.14.258
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Encapsulates call read/unread/trash/restore/delete AJAX actions.
 */
trait SiteStaffr_Admin_Call_Ajax_Trait {

	/**
	 * AJAX handler to mark a call as read.
	 *
	 * @since 0.10.29
	 * @return void
	 */
	public function ajax_mark_call_read() {
		if ( ! check_ajax_referer( 'sitestaffr_ajax_nonce', 'nonce', false ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Mark call read nonce verification failed' );
			wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh the page and try again.', 'sitestaffr' ) ) );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Mark call read permission denied' );
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'sitestaffr' ) ) );
			return;
		}

		$call_id = isset( $_POST['call_id'] ) ? absint( wp_unslash( $_POST['call_id'] ) ) : 0;
		if ( $call_id <= 0 ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Invalid call ID for mark as read' );
			wp_send_json_error( array( 'message' => __( 'Invalid call ID.', 'sitestaffr' ) ) );
			return;
		}

		if ( class_exists( 'SiteStaffr_Call_Manager' ) ) {
			$result = SiteStaffr_Call_Manager::mark_as_read( array( $call_id ) );

			if ( $result ) {
				wp_send_json_success(
					array(
						'message' => __( 'Call marked as read.', 'sitestaffr' ),
						'call_id' => $call_id,
					)
				);
			} else {
				SiteStaffr_Logger::legacy( "SiteStaffr Admin: Failed to mark call #{$call_id} as read" );
				wp_send_json_error( array( 'message' => __( 'Failed to mark call as read. Please try again.', 'sitestaffr' ) ) );
			}
		} else {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: SiteStaffr_Call_Manager class not found' );
			wp_send_json_error( array( 'message' => __( 'System error. Please try again.', 'sitestaffr' ) ) );
		}
	}

	/**
	 * AJAX handler to mark a call as unread.
	 *
	 * @since 0.10.29
	 * @return void
	 */
	public function ajax_mark_call_unread() {
		if ( ! check_ajax_referer( 'sitestaffr_ajax_nonce', 'nonce', false ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Mark call unread nonce verification failed' );
			wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh the page and try again.', 'sitestaffr' ) ) );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Mark call unread permission denied' );
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'sitestaffr' ) ) );
			return;
		}

		$call_id = isset( $_POST['call_id'] ) ? absint( wp_unslash( $_POST['call_id'] ) ) : 0;
		if ( $call_id <= 0 ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Invalid call ID for mark as unread' );
			wp_send_json_error( array( 'message' => __( 'Invalid call ID.', 'sitestaffr' ) ) );
			return;
		}

		global $wpdb;
		$table = $wpdb->prefix . 'phoneease_calls';

			$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- direct row update for call state toggle.
				$table,
				array( 'is_read' => 0 ),
				array( 'id' => $call_id ),
			array( '%d' ),
			array( '%d' )
		);

		if ( $updated !== false ) {
			wp_send_json_success(
				array(
					'message' => __( 'Call marked as unread.', 'sitestaffr' ),
					'call_id' => $call_id,
				)
			);
		} else {
			$updated_dump = wp_json_encode( $updated );
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Failed to mark call #' . $call_id . ' as unread. wpdb->update returned: ' . ( false !== $updated_dump ? $updated_dump : '(json_encode_failed)' ) );
			wp_send_json_error( array( 'message' => __( 'Failed to mark call as unread. Please try again.', 'sitestaffr' ) ) );
		}
	}

	/**
	 * AJAX handler to delete a call (soft delete / trash).
	 *
	 * @since 0.10.28
	 * @return void
	 */
	public function ajax_delete_call() {
		if ( ! check_ajax_referer( 'sitestaffr_ajax_nonce', 'nonce', false ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Delete call nonce verification failed' );
			wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh the page and try again.', 'sitestaffr' ) ) );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Delete call permission denied' );
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'sitestaffr' ) ) );
			return;
		}

		$call_id = isset( $_POST['call_id'] ) ? absint( wp_unslash( $_POST['call_id'] ) ) : 0;
		if ( $call_id <= 0 ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Invalid call ID for delete' );
			wp_send_json_error( array( 'message' => __( 'Invalid call ID.', 'sitestaffr' ) ) );
			return;
		}

		$trashed = SiteStaffr_Call_Manager::trash_calls( array( $call_id ) );

		if ( $trashed !== false && $trashed > 0 ) {
			wp_send_json_success(
				array(
					'message' => __( 'Conversation moved to trash.', 'sitestaffr' ),
					'call_id' => $call_id,
				)
			);
		} else {
			SiteStaffr_Logger::legacy( "SiteStaffr Admin: Failed to trash call #{$call_id}." );
			wp_send_json_error( array( 'message' => __( 'Failed to delete call. Please try again.', 'sitestaffr' ) ) );
		}
	}

	/**
	 * AJAX handler to restore a call from trash.
	 *
	 * @since 0.14.89
	 * @return void
	 */
	public function ajax_restore_call() {
		if ( ! check_ajax_referer( 'sitestaffr_ajax_nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh the page and try again.', 'sitestaffr' ) ) );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'sitestaffr' ) ) );
			return;
		}

		$call_id = isset( $_POST['call_id'] ) ? absint( wp_unslash( $_POST['call_id'] ) ) : 0;
		if ( $call_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid call ID.', 'sitestaffr' ) ) );
			return;
		}

		$restored = SiteStaffr_Call_Manager::restore_calls( array( $call_id ) );
		if ( $restored !== false && $restored > 0 ) {
			wp_send_json_success(
				array(
					'message' => __( 'Conversation restored.', 'sitestaffr' ),
					'call_id' => $call_id,
				)
			);
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to restore conversation. Please try again.', 'sitestaffr' ) ) );
		}
	}

	/**
	 * AJAX handler to permanently delete a call.
	 *
	 * @since 0.14.89
	 * @return void
	 */
	public function ajax_permanent_delete_call() {
		if ( ! check_ajax_referer( 'sitestaffr_ajax_nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh the page and try again.', 'sitestaffr' ) ) );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'sitestaffr' ) ) );
			return;
		}

		$call_id = isset( $_POST['call_id'] ) ? absint( wp_unslash( $_POST['call_id'] ) ) : 0;
		if ( $call_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid call ID.', 'sitestaffr' ) ) );
			return;
		}

		$deleted = SiteStaffr_Call_Manager::delete_calls( array( $call_id ) );
		if ( $deleted !== false && $deleted > 0 ) {
			wp_send_json_success(
				array(
					'message' => __( 'Conversation permanently deleted.', 'sitestaffr' ),
					'call_id' => $call_id,
				)
			);
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to delete conversation. Please try again.', 'sitestaffr' ) ) );
		}
	}
}
