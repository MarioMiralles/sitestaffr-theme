<?php
/**
 * Ban management AJAX handlers for SiteStaffr admin.
 *
 * @package    SiteStaffr
 * @subpackage SiteStaffr/admin/traits
 * @since      0.14.259
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Encapsulates banned-visitor management AJAX actions.
 */
trait SiteStaffr_Admin_Ban_Ajax_Trait {

	/**
	 * AJAX handler: Get all banned visitors.
	 *
	 * @since 0.11.45
	 * @return void
	 */
	public function ajax_get_banned_visitors() {
		if ( ! check_ajax_referer( 'sitestaffr_banned_numbers_nonce', 'nonce', false ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Get banned visitors nonce verification failed' );
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed. Please refresh the page and try again.', 'sitestaffr' ),
				)
			);
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Get banned visitors permission denied' );
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to view banned visitors.', 'sitestaffr' ),
				)
			);
			return;
		}

		if ( ! class_exists( 'SiteStaffr_Ban_Manager' ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: SiteStaffr_Ban_Manager class not found' );
			wp_send_json_error(
				array(
					'message' => __( 'Banned numbers manager not available. Please try again.', 'sitestaffr' ),
				)
			);
			return;
		}

		$banned_numbers = SiteStaffr_Ban_Manager::get_bans();

		wp_send_json_success(
			array(
				'banned_numbers' => $banned_numbers,
				'count'          => count( $banned_numbers ),
			)
		);
	}

	/**
	 * AJAX handler: Ban a visitor.
	 *
	 * @since 0.11.45
	 * @return void
	 */
	public function ajax_ban_visitor() {
		if ( ! check_ajax_referer( 'sitestaffr_banned_numbers_nonce', 'nonce', false ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Ban visitor nonce verification failed' );
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed. Please refresh the page and try again.', 'sitestaffr' ),
				)
			);
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Ban visitor permission denied' );
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to ban visitors.', 'sitestaffr' ),
				)
			);
			return;
		}

		$identifier = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : '';
		$reason     = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : '';

		if ( empty( $identifier ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Ban visitor - visitor identifier is required' );
			wp_send_json_error(
				array(
					'message' => __( 'Identifier is required.', 'sitestaffr' ),
				)
			);
			return;
		}

		if ( ! class_exists( 'SiteStaffr_Ban_Manager' ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: SiteStaffr_Ban_Manager class not found' );
			wp_send_json_error(
				array(
					'message' => __( 'Banned numbers manager not available. Please try again.', 'sitestaffr' ),
				)
			);
			return;
		}

		$ban_type              = 'visitor';
		$normalized_identifier = $identifier;
		if ( filter_var( $identifier, FILTER_VALIDATE_IP ) ) {
			$ban_type = 'ip';
		} else {
			$digits_only = preg_replace( '/\D+/', '', $identifier );
			if ( strlen( $digits_only ) === 10 || strlen( $digits_only ) === 11 ) {
				$ban_type = 'phone';
			}
		}

		$result = SiteStaffr_Ban_Manager::ban( $ban_type, $normalized_identifier, $reason );
		if ( is_wp_error( $result ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Ban visitor failed - ' . $result->get_error_message() );
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
				)
			);
			return;
		}

		wp_send_json_success(
			array(
				// translators: %s: the banned user identifier (IP or fingerprint).
				'message'    => sprintf( __( 'User %s has been banned.', 'sitestaffr' ), $identifier ),
				'identifier' => $identifier,
				'ban_type'   => $ban_type,
			)
		);
	}

	/**
	 * AJAX handler: Unban a visitor.
	 *
	 * @since 0.11.45
	 * @return void
	 */
	public function ajax_unban_visitor() {
		if ( ! check_ajax_referer( 'sitestaffr_banned_numbers_nonce', 'nonce', false ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Unban visitor nonce verification failed' );
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed. Please refresh the page and try again.', 'sitestaffr' ),
				)
			);
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Unban visitor permission denied' );
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to unban visitors.', 'sitestaffr' ),
				)
			);
			return;
		}

		$identifier = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : '';
		$ban_type   = isset( $_POST['ban_type'] ) ? sanitize_key( wp_unslash( $_POST['ban_type'] ) ) : '';
		$ban_key    = isset( $_POST['ban_key'] ) ? sanitize_text_field( wp_unslash( $_POST['ban_key'] ) ) : '';

		if ( empty( $identifier ) ) {
			$identifier = isset( $_POST['phone_number'] ) ? sanitize_text_field( wp_unslash( $_POST['phone_number'] ) ) : '';
		}
		if ( empty( $ban_type ) ) {
			$ban_type = 'phone';
		}

		if ( empty( $identifier ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Unban visitor - visitor identifier is required' );
			wp_send_json_error(
				array(
					'message' => __( 'Identifier is required.', 'sitestaffr' ),
				)
			);
			return;
		}

		if ( ! class_exists( 'SiteStaffr_Ban_Manager' ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: SiteStaffr_Ban_Manager class not found' );
			wp_send_json_error(
				array(
					'message' => __( 'Banned numbers manager not available. Please try again.', 'sitestaffr' ),
				)
			);
			return;
		}

		if ( ! empty( $ban_key ) && method_exists( 'SiteStaffr_Ban_Manager', 'unban_by_key' ) ) {
			$result = SiteStaffr_Ban_Manager::unban_by_key( $ban_key );
		} else {
			$valid_types = array( 'phone', 'visitor', 'ip' );
			if ( ! in_array( $ban_type, $valid_types, true ) ) {
				$ban_type = 'phone';
			}
			$result = SiteStaffr_Ban_Manager::unban( $ban_type, $identifier );
		}

		if ( is_wp_error( $result ) ) {
			SiteStaffr_Logger::legacy( 'SiteStaffr Admin: Unban visitor failed - ' . $result->get_error_message() );
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
				)
			);
			return;
		}

		wp_send_json_success(
			array(
				// translators: %s: the unbanned user identifier (IP or fingerprint).
				'message'    => sprintf( __( 'User %s has been unbanned.', 'sitestaffr' ), $identifier ),
				'identifier' => $identifier,
				'ban_type'   => $ban_type,
			)
		);
	}
}
