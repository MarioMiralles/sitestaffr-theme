<?php
/**
 * My AI Agent admin page.
 *
 * Consolidates AI identity configuration: Knowledge tab + Voice & Behavior tab.
 *
 * @package    SiteStaffr
 * @subpackage SiteStaffr/admin/views
 * @since      1.17.0
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- template variables scoped to this view file.
$settings = get_option( 'sitestaffr_settings', array() );
$admin = $this;
?>
<div class="wrap sitestaffr-my-agent-wrap" style="max-width: 1200px; margin: 0 auto;">
    <?php
    $sitestaffr_page_title = __( 'My AI Agent', 'sitestaffr' );
    include SITESTAFFR_PLUGIN_DIR . 'admin/partials/sitestaffr-header.php';
    ?>

    <div class="sitestaffr-agent-tabs" role="tablist" aria-label="<?php esc_attr_e( 'AI Agent configuration tabs', 'sitestaffr' ); ?>">
        <button type="button" role="tab" class="sitestaffr-agent-tab is-active" aria-selected="true" aria-controls="agent-tab-knowledge" id="agent-tab-btn-knowledge"><?php esc_html_e( 'Knowledge', 'sitestaffr' ); ?></button>
        <button type="button" role="tab" class="sitestaffr-agent-tab" aria-selected="false" aria-controls="agent-tab-voice-behavior" id="agent-tab-btn-voice-behavior" tabindex="-1"><?php esc_html_e( 'Voice & Behavior', 'sitestaffr' ); ?></button>
    </div>

    <!-- Knowledge Tab -->
    <div id="agent-tab-knowledge" role="tabpanel" class="sitestaffr-agent-tabpanel" aria-labelledby="agent-tab-btn-knowledge">
        <?php
        $sitestaffr_embedded = true;
        require SITESTAFFR_PLUGIN_DIR . 'admin/views/admin-knowledge.php';
        ?>
    </div>

    <!-- Voice & Behavior Tab -->
    <div id="agent-tab-voice-behavior" role="tabpanel" class="sitestaffr-agent-tabpanel sitestaffr-settings" aria-labelledby="agent-tab-btn-voice-behavior" hidden>

        <!-- Voice Section -->
        <section class="sitestaffr-settings-card">
            <header class="sitestaffr-settings-card-header">
                <h2>
                    <span class="dashicons dashicons-microphone" aria-hidden="true"></span>
                    <?php esc_html_e( 'AI Voice Agent', 'sitestaffr' ); ?>
                </h2>
            </header>
            <div class="sitestaffr-settings-card-body">
                <p><?php esc_html_e( 'Select and preview the AI voice that represents your business.', 'sitestaffr' ); ?></p>
                <div class="sitestaffr-settings-voice-field">
                    <?php $admin->render_ai_voice_selector(); ?>
                </div>
                <?php if ( $admin->is_custom_greeting_allowed_for_plan( $admin->get_current_plan_key() ) ) : ?>
                    <div class="sitestaffr-agent-greeting-field">
                        <label for="custom_greeting">
                            <?php esc_html_e( 'Custom Greeting', 'sitestaffr' ); ?>
                            <span class="sitestaffr-tooltip-trigger" tabindex="0" role="button" aria-label="<?php esc_attr_e( 'Help', 'sitestaffr' ); ?>" data-tooltip="<?php esc_attr_e( 'Set a short custom opening line your AI voice agent uses at the start of each conversation.', 'sitestaffr' ); ?>">
                                <span class="dashicons dashicons-info" aria-hidden="true"></span>
                            </span>
                            <br><small class="sitestaffr-optional-label">(<?php esc_html_e( 'optional', 'sitestaffr' ); ?>)</small>
                        </label>
                        <?php
                        $admin->render_custom_greeting_field( array(
                            'field_id'    => 'custom_greeting',
                            'placeholder' => 'Hi! Thanks for reaching out to [business name]! How can we help you today?',
                        ) );
                        ?>
                    </div>
                <?php endif; ?>
                <div class="sitestaffr-agent-voice-save-wrap">
                    <button type="button" id="sitestaffr-save-agent-voice" class="button button-primary">
                        <span class="dashicons dashicons-saved" style="vertical-align: middle; margin-right: 5px;" aria-hidden="true"></span>
                        <?php esc_html_e( 'Save Voice Settings', 'sitestaffr' ); ?>
                    </button>
                    <span id="sitestaffr-agent-voice-save-status" class="sitestaffr-inline-status"></span>
                </div>
            </div>
        </section>

        <!-- AI Instructions Section -->
        <?php
        $ai_collect_contact = isset( $settings['ai_collect_contact'] ) ? (bool) $settings['ai_collect_contact'] : true;
        $ai_disregard_personal_info = isset( $settings['ai_disregard_personal_info'] ) ? (bool) $settings['ai_disregard_personal_info'] : false;
        ?>
        <section class="sitestaffr-settings-card">
            <header class="sitestaffr-settings-card-header">
                <h2>
                    <span class="dashicons dashicons-admin-settings" aria-hidden="true"></span>
                    <?php esc_html_e( 'AI Instructions', 'sitestaffr' ); ?>
                </h2>
            </header>
            <div class="sitestaffr-settings-card-body">
                <p><?php esc_html_e( 'Control how your AI agent interacts with visitors.', 'sitestaffr' ); ?></p>

                <div class="sitestaffr-toggle-row">
                    <label class="sitestaffr-toggle-switch">
                        <input type="checkbox"
                            class="sitestaffr-ai-instruction-toggle"
                            data-setting-key="ai_collect_contact"
                            <?php checked( $ai_collect_contact ); ?> />
                        <span class="sitestaffr-toggle-slider"></span>
                    </label>
                    <div class="sitestaffr-toggle-label">
                        <span><?php esc_html_e( 'Collect visitor contact information', 'sitestaffr' ); ?></span>
                        <span class="sitestaffr-tooltip-trigger" tabindex="0" role="button" aria-label="<?php esc_attr_e( 'Help', 'sitestaffr' ); ?>" data-tooltip="<?php esc_attr_e( 'When enabled, your AI agent will ask visitors for their name, phone, email, and reason for reaching out.', 'sitestaffr' ); ?>">
                            <span class="dashicons dashicons-info" aria-hidden="true"></span>
                        </span>
                        <span class="sitestaffr-toggle-status"></span>
                    </div>
                </div>

                <div class="sitestaffr-toggle-row">
                    <label class="sitestaffr-toggle-switch">
                        <input type="checkbox"
                            class="sitestaffr-ai-instruction-toggle"
                            data-setting-key="ai_disregard_personal_info"
                            <?php checked( $ai_disregard_personal_info ); ?> />
                        <span class="sitestaffr-toggle-slider"></span>
                    </label>
                    <div class="sitestaffr-toggle-label">
                        <span><?php esc_html_e( 'Disregard personal details shared by visitors', 'sitestaffr' ); ?></span>
                        <span class="sitestaffr-tooltip-trigger" tabindex="0" role="button" aria-label="<?php esc_attr_e( 'Help', 'sitestaffr' ); ?>" data-tooltip="<?php esc_attr_e( 'When enabled, your AI agent won\'t acknowledge, repeat, or store personal information that visitors voluntarily share during conversation. Recommended for medical portals, legal sites, or any context where visitors may share sensitive details.', 'sitestaffr' ); ?>">
                            <span class="dashicons dashicons-info" aria-hidden="true"></span>
                        </span>
                        <span class="sitestaffr-toggle-status"></span>
                    </div>
                </div>
            </div>
        </section>

        <?php
        $ci_limit = SiteStaffr_Admin::get_custom_instructions_limit( $admin->get_current_plan_key() );
        if ( $ci_limit > 0 ) :
            $ci_list = isset( $settings['custom_instructions_list'] ) ? $settings['custom_instructions_list'] : array();
        ?>
        <section class="sitestaffr-settings-card">
            <header class="sitestaffr-settings-card-header">
                <h2>
                    <span class="dashicons dashicons-edit" aria-hidden="true"></span>
                    <?php esc_html_e( 'Custom Instructions', 'sitestaffr' ); ?>
                    <span class="sitestaffr-ci-count-badge"><?php echo count( $ci_list ); ?> / <?php echo (int) $ci_limit; ?></span>
                </h2>
                <button type="button" id="sitestaffr-add-ci" class="button button-secondary"
                    <?php disabled( count( $ci_list ) >= $ci_limit ); ?>>
                    <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
                    <?php esc_html_e( 'Add Instruction', 'sitestaffr' ); ?>
                </button>
            </header>
            <div class="sitestaffr-settings-card-body">
                <p><?php esc_html_e( 'Add specific instructions for your AI agent. These directives are followed on every conversation.', 'sitestaffr' ); ?></p>

                <div id="sitestaffr-ci-form" class="sitestaffr-ci-form" style="display:none;">
                    <textarea id="sitestaffr-ci-text" class="sitestaffr-ci-textarea" maxlength="200" rows="3" placeholder="<?php esc_attr_e( 'e.g., After answering the first question, ask for name, email, and phone number', 'sitestaffr' ); ?>"></textarea>
                    <div class="sitestaffr-ci-form-footer">
                        <span class="sitestaffr-ci-char-count"><span class="sitestaffr-ci-char-current">0</span> / 200</span>
                        <div class="sitestaffr-ci-form-actions">
                            <button type="button" id="sitestaffr-ci-cancel" class="button"><?php esc_html_e( 'Cancel', 'sitestaffr' ); ?></button>
                            <button type="button" id="sitestaffr-ci-save" class="button button-primary" disabled><?php esc_html_e( 'Save', 'sitestaffr' ); ?></button>
                        </div>
                    </div>
                    <input type="hidden" id="sitestaffr-ci-edit-id" value="" />
                </div>

                <div id="sitestaffr-ci-list">
                    <?php foreach ( $ci_list as $ci ) : ?>
                        <div class="sitestaffr-ci-card" data-ci-id="<?php echo esc_attr( $ci['id'] ); ?>">
                            <label class="sitestaffr-toggle-switch">
                                <input type="checkbox" class="sitestaffr-ci-toggle" <?php checked( ! empty( $ci['enabled'] ) ); ?> />
                                <span class="sitestaffr-toggle-slider"></span>
                            </label>
                            <span class="sitestaffr-ci-text"><?php echo esc_html( $ci['text'] ); ?></span>
                            <span class="sitestaffr-ci-char-badge"><?php echo absint( mb_strlen( $ci['text'] ) ); ?> / 200</span>
                            <span class="sitestaffr-ci-status"></span>
                            <div class="sitestaffr-ci-actions">
                                <button type="button" class="sitestaffr-ci-edit" title="<?php esc_attr_e( 'Edit', 'sitestaffr' ); ?>">
                                    <span class="dashicons dashicons-edit-page"></span>
                                </button>
                                <button type="button" class="sitestaffr-ci-delete" title="<?php esc_attr_e( 'Delete', 'sitestaffr' ); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
