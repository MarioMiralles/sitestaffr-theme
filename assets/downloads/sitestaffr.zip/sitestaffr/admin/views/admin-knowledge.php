<?php
/**
 * AI Knowledge admin page.
 *
 * Lets business owners select pages/posts for AI learning, sync knowledge,
 * and view indexing stats.
 *
 * @package    SiteStaffr
 * @subpackage SiteStaffr/admin/views
 * @since      1.7.0
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$settings = get_option( 'sitestaffr_settings', array() ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- template variable scoped to this view file.
$sitestaffr_embedded = isset( $sitestaffr_embedded ) && $sitestaffr_embedded;
?>
<?php if ( ! $sitestaffr_embedded ) : ?>
<div class="wrap sitestaffr-knowledge-wrap" style="max-width: 1200px; margin: 0 auto;">
	<h1><?php esc_html_e( 'AI Knowledge', 'sitestaffr' ); ?></h1>
	<p class="description"><?php esc_html_e( 'Select pages and posts for your AI assistant to learn from. Synced content helps the AI answer visitor questions accurately.', 'sitestaffr' ); ?></p>
<?php endif; ?>

	<!-- Knowledge Mode -->
	<div class="sitestaffr-knowledge-mode" style="margin: 20px 0; padding: 16px 20px; background: #fff; border: 1px solid #c3c4c7; border-radius: 4px;">
		<h2 style="margin-top: 0; font-size: 14px;"><?php esc_html_e( 'Knowledge Mode', 'sitestaffr' ); ?> <span id="knowledge-mode-status" style="font-size: 12px; font-weight: normal; margin-left: 8px;"></span></h2>
		<p class="description" style="margin-bottom: 12px;"><?php esc_html_e( 'Choose how your AI uses synced knowledge during conversations.', 'sitestaffr' ); ?></p>
		<?php $knowledge_mode = isset( $settings['knowledge_mode'] ) ? $settings['knowledge_mode'] : 'search'; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
		<fieldset>
			<label style="display: flex; align-items: flex-start; gap: 6px; margin-bottom: 8px;">
				<input type="radio" name="sitestaffr_knowledge_mode" value="search" <?php checked( $knowledge_mode, 'search' ); ?> style="margin-top: 4px; flex-shrink: 0;">
				<span><strong><?php esc_html_e( 'Search Mode', 'sitestaffr' ); ?></strong>
				&mdash; <?php esc_html_e( 'Your AI can search across all synced pages to answer visitor questions. Best for sites with a few content pages.', 'sitestaffr' ); ?></span>
			</label>
			<label style="display: flex; align-items: flex-start; gap: 6px;">
				<input type="radio" name="sitestaffr_knowledge_mode" value="page_scoped" <?php checked( $knowledge_mode, 'page_scoped' ); ?> style="margin-top: 4px; flex-shrink: 0;">
				<span><strong><?php esc_html_e( 'Page Expert Mode', 'sitestaffr' ); ?></strong>
				&mdash; <?php esc_html_e( 'Your AI becomes a specialist on each page the visitor is on. Best for sites with many detailed pages (procedures, products, services).', 'sitestaffr' ); ?></span>
			</label>
		</fieldset>
	</div>

	<!-- Stats Section -->
	<div class="sitestaffr-knowledge-stats">
		<div class="stat-card">
			<span class="stat-value" id="stat-chunks">&mdash;</span>
			<span class="stat-label"><?php esc_html_e( 'Chunks Indexed', 'sitestaffr' ); ?></span>
		</div>
		<div class="stat-card">
			<span class="stat-value" id="stat-posts">&mdash;</span>
			<span class="stat-label"><?php esc_html_e( 'Pages Synced', 'sitestaffr' ); ?></span>
		</div>
		<div class="stat-card">
			<span class="stat-value" id="stat-last-sync">&mdash;</span>
			<span class="stat-label"><?php esc_html_e( 'Last Sync', 'sitestaffr' ); ?></span>
		</div>
	</div>

	<!-- Sync Controls -->
	<div class="sitestaffr-knowledge-controls">
		<button type="button" class="button button-primary" id="sync-knowledge-btn" disabled>
			<?php esc_html_e( 'Sync Knowledge', 'sitestaffr' ); ?>
		</button>
		<button type="button" class="button" id="unsync-knowledge-btn" disabled style="margin-left: 8px; color: #b32d2e;">
			<?php esc_html_e( 'Unsync Selected', 'sitestaffr' ); ?>
		</button>
		<button type="button" class="button" id="diagnose-knowledge-btn" style="margin-left: 8px;">
			<?php esc_html_e( 'Diagnose', 'sitestaffr' ); ?>
		</button>
		<button type="button" class="button sitestaffr-add-manual-knowledge" id="sitestaffr-add-standalone-knowledge" style="margin-left: 8px;">
			<span class="dashicons dashicons-plus-alt2" style="vertical-align: middle;"></span>
			<?php esc_html_e( 'Add Knowledge', 'sitestaffr' ); ?>
		</button>
		<span class="sync-status" id="sync-status"></span>
	</div>

	<!-- Manual Knowledge Form -->
	<div id="sitestaffr-manual-knowledge-form" style="display:none;" class="sitestaffr-manual-knowledge-form">
		<h4><?php esc_html_e( 'Add Manual Knowledge', 'sitestaffr' ); ?></h4>
		<p class="description"><?php esc_html_e( 'Add information that isn\'t on your website but your AI should know.', 'sitestaffr' ); ?></p>
		<label for="sitestaffr-manual-title"><?php esc_html_e( 'Title', 'sitestaffr' ); ?></label>
		<input type="text" id="sitestaffr-manual-title" class="regular-text" placeholder="<?php esc_attr_e( 'e.g., Holiday Hours', 'sitestaffr' ); ?>" />
		<label for="sitestaffr-manual-text"><?php esc_html_e( 'Knowledge', 'sitestaffr' ); ?></label>
		<textarea id="sitestaffr-manual-text" rows="4" class="large-text" placeholder="<?php esc_attr_e( 'e.g., We are closed Dec 24-Jan 1 for the holidays. Normal hours resume Jan 2.', 'sitestaffr' ); ?>"></textarea>
		<div class="sitestaffr-manual-knowledge-actions">
			<button type="button" class="button button-primary" id="sitestaffr-save-manual-knowledge">
				<?php esc_html_e( 'Save', 'sitestaffr' ); ?>
			</button>
			<button type="button" class="button" id="sitestaffr-cancel-manual-knowledge">
				<?php esc_html_e( 'Cancel', 'sitestaffr' ); ?>
			</button>
		</div>
	</div>

	<!-- Progress Bar -->
	<div class="sitestaffr-knowledge-progress" id="sync-progress" style="display: none;">
		<div class="progress-bar">
			<div class="progress-fill" id="progress-fill"></div>
		</div>
		<span class="progress-text" id="progress-text"></span>
	</div>

	<!-- Content lists rendered dynamically by admin-knowledge.js -->
	<div id="knowledge-content-sections">
		<p class="loading"><?php esc_html_e( 'Loading...', 'sitestaffr' ); ?></p>
	</div>

<?php if ( ! $sitestaffr_embedded ) : ?>
</div>
<?php endif; ?>
