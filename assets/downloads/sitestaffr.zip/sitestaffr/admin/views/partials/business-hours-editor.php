<?php
/**
 * Business Hours Editor Partial
 *
 * Renders the display/edit interface for business hours in Settings page
 *
 * @package    SiteStaffr
 * @subpackage SiteStaffr/admin/views/partials
 * @since      1.3.9
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

$hours_value = isset( $value ) ? $value : '';
?>

<div class="sitestaffr-hours-editor">
    <div class="sitestaffr-hours-options">
        <label class="sitestaffr-hours-option">
            <input type="radio" name="hours_choice" value="standard" />
            <div class="option-content">
                <strong><?php esc_html_e( 'Mon-Fri 9am-5pm, Sat-Sun Closed', 'sitestaffr' ); ?></strong>
                <p><?php esc_html_e( 'Standard business hours', 'sitestaffr' ); ?></p>
            </div>
        </label>

        <label class="sitestaffr-hours-option">
            <input type="radio" name="hours_choice" value="24/7" />
            <div class="option-content">
                <strong><?php esc_html_e( '24/7 Operations', 'sitestaffr' ); ?></strong>
                <p><?php esc_html_e( 'Your business operates around the clock', 'sitestaffr' ); ?></p>
            </div>
        </label>

        <label class="sitestaffr-hours-option">
            <input type="radio" name="hours_choice" value="custom" />
            <div class="option-content">
                <strong><?php esc_html_e( 'Custom Hours', 'sitestaffr' ); ?></strong>
                <p><?php esc_html_e( 'Set your own schedule', 'sitestaffr' ); ?></p>
            </div>
        </label>
    </div>

    <!-- Schedule Builder (always available for Custom Hours) -->
    <div id="settings-schedule-builder" class="sitestaffr-schedule-builder" style="display: none;">
        <?php
        $days = array( 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' );
        $day_names = array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' );

        foreach ( $days as $index => $day ) :
        ?>
        <div class="sitestaffr-schedule-day">
            <div class="sitestaffr-day-name"><?php echo esc_html( $day_names[ $index ] ); ?></div>
            <div class="sitestaffr-day-controls">
                <label class="sitestaffr-day-toggle">
                    <input type="checkbox" class="day-open-toggle" data-day="<?php echo esc_attr( $day ); ?>" />
                    <span class="toggle-label"><?php esc_html_e( 'Open', 'sitestaffr' ); ?></span>
                </label>
                <div class="sitestaffr-time-inputs" data-day="<?php echo esc_attr( $day ); ?>">
                    <select class="sitestaffr-time-select start-time" data-day="<?php echo esc_attr( $day ); ?>">
                        <!-- Populated by JavaScript -->
                    </select>
                    <span class="sitestaffr-time-separator"><?php esc_html_e( 'to', 'sitestaffr' ); ?></span>
                    <select class="sitestaffr-time-select end-time" data-day="<?php echo esc_attr( $day ); ?>">
                        <!-- Populated by JavaScript -->
                    </select>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Hidden input to store the actual value for form submission -->
    <input type="hidden" id="business_hours" name="sitestaffr_settings[business_hours]" value="<?php echo esc_attr( $hours_value ); ?>" />
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
