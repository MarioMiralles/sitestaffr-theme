<?php
/**
 * Provide a admin settings view for the plugin
 *
 * This file is used to markup the settings page of the plugin.
 *
 * @link       https://github.com/sitestaffr/sitestaffr-plugin
 * @since      1.0.0
 *
 * @package    SiteStaffr
 * @subpackage SiteStaffr/admin/views
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
?>

<div class="wrap sitestaffr-settings">
    <?php
    $sitestaffr_page_title = __( 'Settings', 'sitestaffr' );
    include SITESTAFFR_PLUGIN_DIR . 'admin/partials/sitestaffr-header.php';
    ?>

    <?php
    // Get settings
    $settings = get_option( 'sitestaffr_settings', array() );
    ?>

    <?php
    // Display settings errors/messages
    // Add 'settings-updated' class to suppress duplicate WordPress automatic notices
    settings_errors( 'sitestaffr_settings', false, true );
    ?>

    <form method="post" action="options.php" class="sitestaffr-settings-form">
        <?php
        // Output security fields
        settings_fields( 'sitestaffr_settings_group' );
        ?>

        <div class="sitestaffr-settings-layout">
            <?php
            global $wp_settings_sections, $wp_settings_fields;

            $section_icons = array(
                'sitestaffr_business_section' => 'dashicons-store',
            );

            if ( isset( $wp_settings_sections['sitestaffr-settings'] ) ) :
                foreach ( (array) $wp_settings_sections['sitestaffr-settings'] as $section ) :
                    if ( ! isset( $section['id'] ) ) {
                        continue;
                    }

                    $section_id = $section['id'];
                    $icon_class = isset( $section_icons[ $section_id ] ) ? $section_icons[ $section_id ] : 'dashicons-admin-generic';
                    ?>
                    <section class="sitestaffr-settings-card sitestaffr-settings-card-<?php echo esc_attr( sanitize_html_class( $section_id ) ); ?>">
                        <header class="sitestaffr-settings-card-header">
                            <h2>
                                <span class="dashicons <?php echo esc_attr( $icon_class ); ?>" aria-hidden="true"></span>
                                <?php echo esc_html( $section['title'] ); ?>
                            </h2>
                        </header>
                        <div class="sitestaffr-settings-card-body">
                            <?php
                            if ( ! empty( $section['callback'] ) ) {
                                call_user_func( $section['callback'], $section );
                            }
                            ?>

                            <?php if ( isset( $wp_settings_fields['sitestaffr-settings'][ $section_id ] ) ) : ?>
                                <?php if ( 'sitestaffr_business_section' === $section_id ) : ?>
                                    <?php
                                    $business_fields = $wp_settings_fields['sitestaffr-settings'][ $section_id ];
                                    $business_main_order = array( 'business_name', 'business_phone', 'business_context' );
                                    $hours_field = isset( $business_fields['business_hours'] ) ? $business_fields['business_hours'] : null;
                                    ?>
                                    <div class="sitestaffr-business-grid">
                                        <div class="sitestaffr-business-main">
                                            <?php foreach ( $business_main_order as $field_key ) : ?>
                                                <?php if ( empty( $business_fields[ $field_key ] ) ) : ?>
                                                    <?php continue; ?>
                                                <?php endif; ?>
                                                <?php $field = $business_fields[ $field_key ]; ?>
                                                <div class="sitestaffr-business-row sitestaffr-business-row-<?php echo esc_attr( sanitize_html_class( $field_key ) ); ?>">
                                                    <div class="sitestaffr-business-label">
                                                        <label for="<?php echo esc_attr( $field_key ); ?>">
                                                            <?php echo wp_kses_post( $field['title'] ); ?>
                                                        </label>
                                                        <?php if ( 'business_context' === $field_key ) : ?>
                                                            <?php
                                                            $remaining_gens = method_exists( $this, 'get_remaining_description_generations' )
                                                                ? $this->get_remaining_description_generations()
                                                                : 0;
                                                            $remaining_gens = max( 0, (int) $remaining_gens );
                                                            ?>
                                                            <div
                                                                class="sitestaffr-generate-card"
                                                                data-remaining-generations="<?php echo esc_attr( $remaining_gens ); ?>"
                                                            >
                                                                <button
                                                                    type="button"
                                                                    id="btn-settings-generate-description"
                                                                    class="button button-secondary sitestaffr-generate-btn"
                                                                    aria-describedby="sitestaffr-gen-status"
                                                                    <?php echo $remaining_gens <= 0 ? 'disabled' : ''; ?>
                                                                >
                                                                    <span class="sitestaffr-gen-button-ripple" aria-hidden="true"></span>
                                                                    <span class="dashicons dashicons-update"></span>
                                                                    <?php esc_html_e( 'Generate Identity', 'sitestaffr' ); ?>
                                                                </button>
                                                                <div class="sitestaffr-gen-progress" aria-hidden="true">
                                                                    <div class="sitestaffr-gen-progress-bar"></div>
                                                                </div>
                                                                <p id="sitestaffr-gen-status" class="sitestaffr-gen-status" aria-live="polite"></p>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="sitestaffr-business-control">
                                                        <?php call_user_func( $field['callback'], $field['args'] ); ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>

                                        <?php if ( $hours_field ) : ?>
                                            <aside class="sitestaffr-business-hours-panel">
                                                <h3><?php echo wp_kses_post( $hours_field['title'] ); ?></h3>
                                                <div class="sitestaffr-business-hours-control">
                                                    <?php call_user_func( $hours_field['callback'], $hours_field['args'] ); ?>
                                                </div>
                                            </aside>
                                        <?php endif; ?>
                                    </div>
                                    <div class="sitestaffr-business-guidance-modal" data-sitestaffr-guidance-modal hidden>
                                        <div class="sitestaffr-business-guidance-backdrop" data-sitestaffr-guidance-close></div>
                                        <div class="sitestaffr-business-guidance-dialog" role="dialog" aria-modal="true" aria-labelledby="sitestaffr-business-guidance-title">
                                            <button type="button" class="sitestaffr-business-guidance-close" aria-label="<?php esc_attr_e( 'Close guidance', 'sitestaffr' ); ?>" data-sitestaffr-guidance-close>&times;</button>
                                            <h3 id="sitestaffr-business-guidance-title"><?php esc_html_e( 'How to: Write a Great Business Identity', 'sitestaffr' ); ?></h3>
                                            <ul>
                                                <li><?php esc_html_e( 'Explain what your business does in 2-3 sentences: services, industries served, and what sets you apart.', 'sitestaffr' ); ?></li>
                                                <li><?php esc_html_e( 'List your key services or products by name. Detailed descriptions are handled by your Knowledge Base.', 'sitestaffr' ); ?></li>
                                                <li><?php esc_html_e( 'Include any promotions, seasonal offers, or internal knowledge the AI should know.', 'sitestaffr' ); ?></li>
                                                <li><?php esc_html_e( 'Keep it concise — this is your business\'s elevator pitch, not an encyclopedia.', 'sitestaffr' ); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                <?php elseif ( 'sitestaffr_ai_receptionist_voice_section' === $section_id ) : ?>
                                    <div class="sitestaffr-settings-voice-field">
                                        <?php foreach ( $wp_settings_fields['sitestaffr-settings'][ $section_id ] as $field ) : ?>
                                            <?php call_user_func( $field['callback'], $field['args'] ); ?>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else : ?>
                                    <table class="form-table" role="presentation">
                                        <tbody>
                                            <?php do_settings_fields( 'sitestaffr-settings', $section_id ); ?>
                                        </tbody>
                                    </table>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if ( 'sitestaffr_business_section' === $section_id ) : ?>
                                <div class="sitestaffr-settings-save-wrap">
                                    <button type="button" id="sitestaffr-save-business-settings" class="button button-primary sitestaffr-settings-save-button">
                                        <span class="dashicons dashicons-saved" style="vertical-align: middle; margin-right: 5px;" aria-hidden="true"></span>
                                        <span class="sitestaffr-save-business-text"><?php esc_html_e( 'Update Business Information', 'sitestaffr' ); ?></span>
                                    </button>
                                    <span id="sitestaffr-business-save-status" class="sitestaffr-inline-status" style="margin-left: 10px;"></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>
                    <?php
                endforeach;
            endif;
            ?>
        </div>

    </form>

    <!-- Settings page JS enqueued via class-sitestaffr-admin.php (sitestaffr-settings-page.js) -->

    <!-- Email Notification Settings -->
    <section class="sitestaffr-settings-card sitestaffr-settings-card-email sitestaffr-email-notifications">
        <header class="sitestaffr-settings-card-header">
            <h2>
                <span class="dashicons dashicons-email-alt" aria-hidden="true"></span>
                <?php esc_html_e( 'Email Notification Settings', 'sitestaffr' ); ?>
            </h2>
        </header>
        <div class="sitestaffr-settings-card-body">
        <?php
        $settings = get_option( 'sitestaffr_settings', array() );
        $notifications_enabled = ! isset( $settings['email_notifications_enabled'] ) || $settings['email_notifications_enabled'];
        $notification_email = ! empty( $settings['notification_email'] ) ? $settings['notification_email'] : get_option( 'admin_email' );
        $notification_cc_emails = ! empty( $settings['notification_cc_emails'] ) ? $settings['notification_cc_emails'] : '';

        ?>

        <div class="sitestaffr-email-layout">
            <div class="sitestaffr-email-primary">
                <div class="sitestaffr-email-row">
                    <div class="sitestaffr-email-row-label">
                        <label for="sitestaffr_email_notifications_enabled"><?php esc_html_e( 'Enable Notifications', 'sitestaffr' ); ?></label>
                        <span class="sitestaffr-tooltip-trigger" tabindex="0" role="button" aria-label="<?php esc_attr_e( 'Help', 'sitestaffr' ); ?>" data-tooltip="<?php esc_attr_e( 'When enabled, SiteStaffr sends an email recap after each completed conversation, including summary and follow-up details, with a button to view full conversation details.', 'sitestaffr' ); ?>">
                            <span class="dashicons dashicons-info" aria-hidden="true"></span>
                        </span>
                    </div>
                    <div class="sitestaffr-email-row-control">
                        <label class="sitestaffr-email-checkbox-label">
                            <input type="checkbox" id="sitestaffr_email_notifications_enabled" name="sitestaffr_email_notifications_enabled" value="1" <?php checked( $notifications_enabled ); ?> />
                            <?php esc_html_e( 'Send email notifications when conversations are completed', 'sitestaffr' ); ?>
                        </label>
                    </div>
                </div>

                <div class="sitestaffr-email-row">
                    <div class="sitestaffr-email-row-label">
                        <label for="sitestaffr_notification_email"><?php esc_html_e( 'Notification Email', 'sitestaffr' ); ?></label>
                    </div>
                    <div class="sitestaffr-email-row-control">
                        <input type="email"
                            id="sitestaffr_notification_email"
                            name="sitestaffr_notification_email"
                            value="<?php echo esc_attr( $notification_email ); ?>"
                            class="regular-text"
                            placeholder="your@email.com" />
                    </div>
                </div>

                <div class="sitestaffr-email-row">
                    <div class="sitestaffr-email-row-label">
                        <label for="sitestaffr_notification_cc_emails"><?php esc_html_e( 'Additional Emails (CC)', 'sitestaffr' ); ?></label>
                        <span class="sitestaffr-tooltip-trigger" tabindex="0" role="button" aria-label="<?php esc_attr_e( 'Help', 'sitestaffr' ); ?>" data-tooltip="<?php esc_attr_e( 'Separate multiple emails with commas. Up to 5 additional addresses can be CC\'d, and each address will receive new message notifications.', 'sitestaffr' ); ?>">
                            <span class="dashicons dashicons-info" aria-hidden="true"></span>
                        </span>
                    </div>
                    <div class="sitestaffr-email-row-control">
                        <input type="text"
                            id="sitestaffr_notification_cc_emails"
                            name="sitestaffr_notification_cc_emails"
                            value="<?php echo esc_attr( $notification_cc_emails ); ?>"
                            class="regular-text sitestaffr-notification-cc-input"
                            placeholder="manager@example.com, team@example.com" />
                    </div>
                </div>

                <div class="sitestaffr-email-row sitestaffr-email-row-actions">
                    <button type="button"
                        id="sitestaffr-save-notification-settings"
                        class="button button-primary">
                        <span class="dashicons dashicons-saved" style="vertical-align: middle; margin-right: 5px;"></span>
                        <span class="sitestaffr-save-notif-text"><?php esc_html_e( 'Save Notification Settings', 'sitestaffr' ); ?></span>
                    </button>
                    <span id="sitestaffr-notif-save-status" class="sitestaffr-inline-status" style="margin-left: 10px;"></span>
                </div>
            </div>

            <aside class="sitestaffr-email-test-panel">
                <h3><?php esc_html_e( 'Test Email Notifications', 'sitestaffr' ); ?></h3>
                <p><?php esc_html_e( 'Send a test email to verify your notification settings are working correctly.', 'sitestaffr' ); ?></p>
                <button type="button" id="sitestaffr-send-test-email" class="button button-secondary">
                    <span class="dashicons dashicons-email" style="vertical-align: middle; margin-right: 5px;"></span>
                    <?php esc_html_e( 'Send Test Email', 'sitestaffr' ); ?>
                </button>
                <span id="sitestaffr-test-email-status" class="sitestaffr-inline-status"></span>
            </aside>
        </div>
        </div>
    </section>

</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
