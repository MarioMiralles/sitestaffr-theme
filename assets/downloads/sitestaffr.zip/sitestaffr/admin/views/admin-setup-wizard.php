<?php
/**
 * Setup Wizard View - Mandatory 3-Step Flow
 *
 * Guides new users through: Business Info → Choose Plan → Enhance AI.
 * Blocks all features until completion.
 *
 * @package    SiteStaffr
 * @subpackage SiteStaffr/admin/views
 * @since      1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

// Get pre-filled values
$site_name   = get_bloginfo( 'name' );
$settings    = get_option( 'sitestaffr_settings', array() );

$business_name        = isset( $settings['business_name'] ) ? stripslashes( $settings['business_name'] ) : $site_name;
$business_description = isset( $settings['business_context'] ) ? stripslashes( $settings['business_context'] ) : '';
$business_phone       = isset( $settings['business_phone'] ) ? stripslashes( $settings['business_phone'] ) : '';
$business_hours_type  = isset( $settings['business_hours_type'] ) ? stripslashes( $settings['business_hours_type'] ) : '24_7';

// Detect return from Stripe Checkout (redirect URL set by external Stripe service; cannot embed WP nonce).
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- external redirect; value is sanitize_key'd and compared against allowlist below.
$checkout_complete = isset( $_GET['checkout_complete'] ) ? sanitize_key( wp_unslash( $_GET['checkout_complete'] ) ) : '';
?>

<div class="wrap sitestaffr-setup-wizard">
    <?php
    $sitestaffr_page_title = __( 'Setup Wizard', 'sitestaffr' );
    $sitestaffr_suppress_low_balance_alert = true;
    $sitestaffr_suppress_buy_minutes_modal = true;
    include SITESTAFFR_PLUGIN_DIR . 'admin/partials/sitestaffr-header.php';
    ?>

    <div class="sitestaffr-wizard-container">

        <!-- Progress Bar -->
        <div class="sitestaffr-wizard-progress">
            <div class="sitestaffr-progress-bar">
                <div class="sitestaffr-progress-fill" id="progress-fill" style="width: 33%;"></div>
            </div>
            <div class="sitestaffr-progress-steps">
                <span class="sitestaffr-step active" data-step="1" id="step-indicator-1">1</span>
                <span class="sitestaffr-step" data-step="2" id="step-indicator-2">2</span>
                <span class="sitestaffr-step" data-step="3" id="step-indicator-3">3</span>
            </div>
            <p class="sitestaffr-progress-text">
                <?php esc_html_e( 'Step', 'sitestaffr' ); ?> <span id="current-step">1</span> <?php esc_html_e( 'of', 'sitestaffr' ); ?> 3
            </p>
        </div>

        <!-- Wizard Form -->
        <form id="sitestaffr-setup-form" method="post">
            <?php wp_nonce_field( 'sitestaffr_setup_wizard', 'sitestaffr_wizard_nonce' ); ?>

            <!-- Step 1: Business Info -->
            <div class="sitestaffr-wizard-step active" data-step="1" id="wizard-step-1">
                <div class="sitestaffr-step-content">
                    <h2><?php esc_html_e( 'Welcome to SiteStaffr', 'sitestaffr' ); ?></h2>
                    <p class="sitestaffr-step-description">
                        <?php esc_html_e( "Let's get your AI agent set up. Tell us about your business.", 'sitestaffr' ); ?>
                    </p>

                    <div class="sitestaffr-field-group">
                        <label class="sitestaffr-field-label" for="business_name">
                            <?php esc_html_e( 'Business Name', 'sitestaffr' ); ?> <span style="color: #d63638;">*</span>
                        </label>
                        <input
                            type="text"
                            id="business_name"
                            name="business_name"
                            class="sitestaffr-input"
                            placeholder="<?php esc_attr_e( "e.g., Joe's Plumbing", 'sitestaffr' ); ?>"
                            value="<?php echo esc_attr( $business_name ); ?>"
                            required
                        >
                    </div>

                    <div class="sitestaffr-field-group">
                        <label class="sitestaffr-field-label" for="business-phone-step1">
                            <?php esc_html_e( 'Business Phone Number', 'sitestaffr' ); ?> <span style="color: #d63638;">*</span>
                        </label>
                        <input
                            type="tel"
                            id="business-phone-step1"
                            name="business_phone_step1"
                            class="sitestaffr-input"
                            placeholder="<?php esc_attr_e( '(XXX) XXX-XXXX', 'sitestaffr' ); ?>"
                            value="<?php echo esc_attr( get_option( 'sitestaffr_business_phone', '' ) ); ?>"
                            required
                            maxlength="14"
                        >
                        <span class="sitestaffr-field-error" id="business-phone-error" style="display: none; color: #d63638; font-size: 14px; margin-top: 4px;">
                            <?php esc_html_e( 'Please enter a valid phone number in format: (XXX) XXX-XXXX', 'sitestaffr' ); ?>
                        </span>
                    </div>

                    <div class="sitestaffr-field-group">
                        <label class="sitestaffr-field-label" for="business-email-step1">
                            <?php esc_html_e( 'Business Email', 'sitestaffr' ); ?> <span style="color: #d63638;">*</span>
                        </label>
                        <input
                            type="email"
                            id="business-email-step1"
                            name="business_email"
                            class="sitestaffr-input"
                            placeholder="<?php esc_attr_e( 'you@yourbusiness.com', 'sitestaffr' ); ?>"
                            value="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>"
                            required
                        >
                        <p class="description"><?php esc_html_e( 'Used for notifications, billing, and account management.', 'sitestaffr' ); ?></p>
                    </div>

                    <p class="sitestaffr-wizard-legal">
                        <?php
                        printf(
                            /* translators: 1: opening link tag for Terms, 2: closing link tag, 3: opening link tag for Privacy Policy, 4: closing link tag */
                            esc_html__( 'By continuing, you agree to SiteStaffr\'s %1$sTerms of Service%2$s and %3$sPrivacy Policy%4$s.', 'sitestaffr' ),
                            '<a href="https://sitestaffr.com/terms" target="_blank" rel="noopener noreferrer">',
                            '</a>',
                            '<a href="https://sitestaffr.com/privacy" target="_blank" rel="noopener noreferrer">',
                            '</a>'
                        );
                        ?>
                    </p>
                </div>
            </div>

            <!-- Step 2: Choose Your Plan -->
            <div class="sitestaffr-wizard-step" data-step="2" id="wizard-step-2">
                <div class="sitestaffr-step-content">
                    <h2><?php esc_html_e( 'Choose Your Plan', 'sitestaffr' ); ?></h2>
                    <p class="sitestaffr-step-description">
                        <?php esc_html_e( 'Select the plan that fits your business needs.', 'sitestaffr' ); ?>
                    </p>

                    <div class="sitestaffr-plan-cards">
                        <div class="sitestaffr-plan-card" data-plan="starter">
                            <div class="sitestaffr-plan-name"><?php esc_html_e( 'Starter', 'sitestaffr' ); ?></div>
                            <div class="sitestaffr-plan-price">$10<span>/<?php esc_html_e( 'mo', 'sitestaffr' ); ?></span></div>
                            <div class="sitestaffr-plan-minutes"><?php esc_html_e( '60 minutes included', 'sitestaffr' ); ?></div>
                            <ul class="sitestaffr-plan-features">
                                <li><?php esc_html_e( '2 AI voice options', 'sitestaffr' ); ?></li>
                                <li><?php esc_html_e( '57+ languages', 'sitestaffr' ); ?></li>
                                <li><?php esc_html_e( 'Email summaries after every call', 'sitestaffr' ); ?></li>
                            </ul>
                            <button type="button" class="sitestaffr-plan-select-btn" data-plan="starter">
                                <?php esc_html_e( 'Select Starter', 'sitestaffr' ); ?>
                            </button>
                        </div>

                        <div class="sitestaffr-plan-card sitestaffr-plan-popular" data-plan="business">
                            <div class="sitestaffr-plan-badge"><?php esc_html_e( 'Most Popular', 'sitestaffr' ); ?></div>
                            <div class="sitestaffr-plan-name"><?php esc_html_e( 'Business', 'sitestaffr' ); ?></div>
                            <div class="sitestaffr-plan-price">$50<span>/<?php esc_html_e( 'mo', 'sitestaffr' ); ?></span></div>
                            <div class="sitestaffr-plan-minutes"><?php esc_html_e( '300 minutes included', 'sitestaffr' ); ?></div>
                            <ul class="sitestaffr-plan-features">
                                <li><?php esc_html_e( '5 AI voice options', 'sitestaffr' ); ?></li>
                                <li><?php esc_html_e( 'Custom greeting message', 'sitestaffr' ); ?></li>
                                <li><?php esc_html_e( '57+ languages', 'sitestaffr' ); ?></li>
                            </ul>
                            <button type="button" class="sitestaffr-plan-select-btn" data-plan="business">
                                <?php esc_html_e( 'Select Business', 'sitestaffr' ); ?>
                            </button>
                        </div>

                        <div class="sitestaffr-plan-card" data-plan="pro">
                            <div class="sitestaffr-plan-name"><?php esc_html_e( 'Pro', 'sitestaffr' ); ?></div>
                            <div class="sitestaffr-plan-price">$100<span>/<?php esc_html_e( 'mo', 'sitestaffr' ); ?></span></div>
                            <div class="sitestaffr-plan-minutes"><?php esc_html_e( '700 minutes included', 'sitestaffr' ); ?></div>
                            <ul class="sitestaffr-plan-features">
                                <li><?php esc_html_e( 'All 10 AI voices', 'sitestaffr' ); ?></li>
                                <li><?php esc_html_e( 'Custom greeting message', 'sitestaffr' ); ?></li>
                                <li><?php esc_html_e( '57+ languages', 'sitestaffr' ); ?></li>
                            </ul>
                            <button type="button" class="sitestaffr-plan-select-btn" data-plan="pro">
                                <?php esc_html_e( 'Select Pro', 'sitestaffr' ); ?>
                            </button>
                        </div>
                    </div>

                    <div class="sitestaffr-free-trial-link">
                        <a href="#" id="start-free-trial"><?php esc_html_e( 'Start with a free trial instead', 'sitestaffr' ); ?> &rarr;</a>
                        <p><?php esc_html_e( '30 minutes free for 30 days — no credit card required', 'sitestaffr' ); ?></p>
                    </div>

                    <div class="sitestaffr-step-back-row">
                        <button type="button" class="sitestaffr-step-back-link" id="back-to-step-1">
                            <span class="dashicons dashicons-arrow-left-alt"></span>
                            <?php esc_html_e( 'Back to Business Info', 'sitestaffr' ); ?>
                        </button>
                    </div>

                </div>
            </div>

            <!-- Step 3: Train Your AI Agent -->
            <div class="sitestaffr-wizard-step" data-step="3" id="wizard-step-3">
                <div class="sitestaffr-step-content" id="wizard-step-3-content">
                    <h2><?php esc_html_e( 'Train Your AI Agent', 'sitestaffr' ); ?></h2>
                    <p class="sitestaffr-step-description">
                        <?php esc_html_e( 'Set your hours and generate a business description so your AI can answer visitor questions accurately.', 'sitestaffr' ); ?>
                    </p>

                    <!-- Business Hours Section Header -->
                    <div class="sitestaffr-wizard-section-header">
                        <?php esc_html_e( 'Business Hours', 'sitestaffr' ); ?> <span style="color: #d63638;">*</span>
                    </div>

                    <!-- Business Hours -->
                    <div class="sitestaffr-field-group">
                        <p class="sitestaffr-field-helper" style="margin-bottom: 12px;">
                            <strong><?php esc_html_e( 'When is your physical business open?', 'sitestaffr' ); ?></strong><br>
                            <?php esc_html_e( 'The AI answers calls 24/7, but needs to know your actual operating hours to inform visitors.', 'sitestaffr' ); ?>
                        </p>

                        <div class="sitestaffr-radio-option">
                            <label>
                                <input type="radio" name="business_hours_option" value="Mon-Fri 9am-5pm, Sat-Sun Closed">
                                <div class="sitestaffr-radio-content">
                                    <strong><?php esc_html_e( 'Mon-Fri 9am-5pm, Sat-Sun Closed', 'sitestaffr' ); ?></strong>
                                    <p class="description"><?php esc_html_e( 'Standard business hours', 'sitestaffr' ); ?></p>
                                </div>
                            </label>
                        </div>

                        <div class="sitestaffr-radio-option">
                            <label>
                                <input type="radio" name="business_hours_option" value="24/7">
                                <div class="sitestaffr-radio-content">
                                    <strong><?php esc_html_e( '24/7 Operations', 'sitestaffr' ); ?></strong>
                                    <p class="description"><?php esc_html_e( 'Your business operates around the clock', 'sitestaffr' ); ?></p>
                                </div>
                            </label>
                        </div>

                        <div class="sitestaffr-radio-option" id="custom-hours-container">
                            <label>
                                <input type="radio" name="business_hours_option" value="custom" id="hours_custom">
                                <div class="sitestaffr-radio-content">
                                    <strong><?php esc_html_e( 'Custom Hours', 'sitestaffr' ); ?></strong>
                                    <p class="description"><?php esc_html_e( 'Set your own schedule', 'sitestaffr' ); ?></p>
                                </div>
                            </label>

                            <!-- Schedule Builder (shown when Custom selected) -->
                            <div id="schedule-builder" class="sitestaffr-schedule-builder" style="display: none; margin: 12px 0 0 28px; width: calc(100% - 28px);">
                                <!-- Monday -->
                                <div class="sitestaffr-schedule-day">
                                    <div class="sitestaffr-day-name"><?php esc_html_e( 'Monday', 'sitestaffr' ); ?></div>
                                    <div class="sitestaffr-day-controls">
                                        <label class="sitestaffr-day-toggle">
                                            <input type="checkbox" class="day-open-toggle" data-day="monday" checked>
                                            <span class="toggle-label"><?php esc_html_e( 'Open', 'sitestaffr' ); ?></span>
                                        </label>
                                        <div class="sitestaffr-time-inputs" data-day="monday">
                                            <select class="sitestaffr-time-select start-time" data-day="monday"></select>
                                            <span class="sitestaffr-time-separator"><?php esc_html_e( 'to', 'sitestaffr' ); ?></span>
                                            <select class="sitestaffr-time-select end-time" data-day="monday"></select>
                                        </div>
                                    </div>
                                </div>
                                <!-- Tuesday -->
                                <div class="sitestaffr-schedule-day">
                                    <div class="sitestaffr-day-name"><?php esc_html_e( 'Tuesday', 'sitestaffr' ); ?></div>
                                    <div class="sitestaffr-day-controls">
                                        <label class="sitestaffr-day-toggle">
                                            <input type="checkbox" class="day-open-toggle" data-day="tuesday" checked>
                                            <span class="toggle-label"><?php esc_html_e( 'Open', 'sitestaffr' ); ?></span>
                                        </label>
                                        <div class="sitestaffr-time-inputs" data-day="tuesday">
                                            <select class="sitestaffr-time-select start-time" data-day="tuesday"></select>
                                            <span class="sitestaffr-time-separator"><?php esc_html_e( 'to', 'sitestaffr' ); ?></span>
                                            <select class="sitestaffr-time-select end-time" data-day="tuesday"></select>
                                        </div>
                                    </div>
                                </div>
                                <!-- Wednesday -->
                                <div class="sitestaffr-schedule-day">
                                    <div class="sitestaffr-day-name"><?php esc_html_e( 'Wednesday', 'sitestaffr' ); ?></div>
                                    <div class="sitestaffr-day-controls">
                                        <label class="sitestaffr-day-toggle">
                                            <input type="checkbox" class="day-open-toggle" data-day="wednesday" checked>
                                            <span class="toggle-label"><?php esc_html_e( 'Open', 'sitestaffr' ); ?></span>
                                        </label>
                                        <div class="sitestaffr-time-inputs" data-day="wednesday">
                                            <select class="sitestaffr-time-select start-time" data-day="wednesday"></select>
                                            <span class="sitestaffr-time-separator"><?php esc_html_e( 'to', 'sitestaffr' ); ?></span>
                                            <select class="sitestaffr-time-select end-time" data-day="wednesday"></select>
                                        </div>
                                    </div>
                                </div>
                                <!-- Thursday -->
                                <div class="sitestaffr-schedule-day">
                                    <div class="sitestaffr-day-name"><?php esc_html_e( 'Thursday', 'sitestaffr' ); ?></div>
                                    <div class="sitestaffr-day-controls">
                                        <label class="sitestaffr-day-toggle">
                                            <input type="checkbox" class="day-open-toggle" data-day="thursday" checked>
                                            <span class="toggle-label"><?php esc_html_e( 'Open', 'sitestaffr' ); ?></span>
                                        </label>
                                        <div class="sitestaffr-time-inputs" data-day="thursday">
                                            <select class="sitestaffr-time-select start-time" data-day="thursday"></select>
                                            <span class="sitestaffr-time-separator"><?php esc_html_e( 'to', 'sitestaffr' ); ?></span>
                                            <select class="sitestaffr-time-select end-time" data-day="thursday"></select>
                                        </div>
                                    </div>
                                </div>
                                <!-- Friday -->
                                <div class="sitestaffr-schedule-day">
                                    <div class="sitestaffr-day-name"><?php esc_html_e( 'Friday', 'sitestaffr' ); ?></div>
                                    <div class="sitestaffr-day-controls">
                                        <label class="sitestaffr-day-toggle">
                                            <input type="checkbox" class="day-open-toggle" data-day="friday" checked>
                                            <span class="toggle-label"><?php esc_html_e( 'Open', 'sitestaffr' ); ?></span>
                                        </label>
                                        <div class="sitestaffr-time-inputs" data-day="friday">
                                            <select class="sitestaffr-time-select start-time" data-day="friday"></select>
                                            <span class="sitestaffr-time-separator"><?php esc_html_e( 'to', 'sitestaffr' ); ?></span>
                                            <select class="sitestaffr-time-select end-time" data-day="friday"></select>
                                        </div>
                                    </div>
                                </div>
                                <!-- Saturday -->
                                <div class="sitestaffr-schedule-day">
                                    <div class="sitestaffr-day-name"><?php esc_html_e( 'Saturday', 'sitestaffr' ); ?></div>
                                    <div class="sitestaffr-day-controls">
                                        <label class="sitestaffr-day-toggle">
                                            <input type="checkbox" class="day-open-toggle" data-day="saturday">
                                            <span class="toggle-label"><?php esc_html_e( 'Closed', 'sitestaffr' ); ?></span>
                                        </label>
                                        <div class="sitestaffr-time-inputs" data-day="saturday" style="display: none;">
                                            <select class="sitestaffr-time-select start-time" data-day="saturday"></select>
                                            <span class="sitestaffr-time-separator"><?php esc_html_e( 'to', 'sitestaffr' ); ?></span>
                                            <select class="sitestaffr-time-select end-time" data-day="saturday"></select>
                                        </div>
                                    </div>
                                </div>
                                <!-- Sunday -->
                                <div class="sitestaffr-schedule-day">
                                    <div class="sitestaffr-day-name"><?php esc_html_e( 'Sunday', 'sitestaffr' ); ?></div>
                                    <div class="sitestaffr-day-controls">
                                        <label class="sitestaffr-day-toggle">
                                            <input type="checkbox" class="day-open-toggle" data-day="sunday">
                                            <span class="toggle-label"><?php esc_html_e( 'Closed', 'sitestaffr' ); ?></span>
                                        </label>
                                        <div class="sitestaffr-time-inputs" data-day="sunday" style="display: none;">
                                            <select class="sitestaffr-time-select start-time" data-day="sunday"></select>
                                            <span class="sitestaffr-time-separator"><?php esc_html_e( 'to', 'sitestaffr' ); ?></span>
                                            <select class="sitestaffr-time-select end-time" data-day="sunday"></select>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- /#schedule-builder -->
                        </div>
                    </div>

                    <!-- Business Identity Section Header -->
                    <div class="sitestaffr-wizard-section-header">
                        <?php esc_html_e( 'Business Identity', 'sitestaffr' ); ?> <span style="color: #d63638;">*</span>
                    </div>

                    <!-- Business Identity -->
                    <div class="sitestaffr-field-group">
                        <!-- Website Scan -->
                        <div id="website-scan-option" class="sitestaffr-description-option">
                            <div id="scan-hero" class="sitestaffr-scan-hero">
                                <div class="sitestaffr-scan-hero-glow"></div>
                                <div class="sitestaffr-scan-hero-content">
                                    <div class="sitestaffr-scan-hero-icon">
                                        <span class="dashicons dashicons-superhero-alt"></span>
                                    </div>
                                    <p class="sitestaffr-scan-hero-title"><?php esc_html_e( 'Create Your AI Knowledge Base', 'sitestaffr' ); ?></p>
                                    <p class="sitestaffr-scan-hero-subtitle"><?php esc_html_e( 'We\'ll analyze your website content and teach your AI everything about your business.', 'sitestaffr' ); ?></p>
                                    <button type="button" id="btn-scan-website" class="sitestaffr-btn-scan-hero">
                                        <span class="dashicons dashicons-admin-generic"></span>
                                        <?php esc_html_e( 'Generate', 'sitestaffr' ); ?>
                                    </button>
                                </div>
                            </div>

                            <div id="scan-showcase" class="sitestaffr-scan-showcase" style="display:none;">
                                <div class="sitestaffr-scan-glow"></div>
                                <div class="sitestaffr-scan-content">
                                    <div class="sitestaffr-scan-core"><span class="dashicons dashicons-admin-generic"></span></div>
                                    <p class="sitestaffr-scan-title" id="scan-status-text"><?php esc_html_e( 'Preparing your content...', 'sitestaffr' ); ?></p>
                                    <p class="sitestaffr-scan-subtitle" id="scan-status-detail"></p>
                                    <div class="sitestaffr-scan-progress" aria-hidden="true">
                                        <div class="sitestaffr-scan-progress-bar" id="scan-progress-bar" style="width: 5%;"></div>
                                    </div>
                                </div>
                            </div>

                            <div id="generated-description" class="sitestaffr-generated-container" style="display: none;">
                                <div class="sitestaffr-generated-box">
                                    <p id="generated-text"></p>
                                    <button type="button" id="btn-edit-generated" class="sitestaffr-btn-edit">
                                        <?php esc_html_e( 'Edit', 'sitestaffr' ); ?>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Manual Edit (shown after generation or on fallback) -->
                        <div id="manual-entry-option" class="sitestaffr-description-option" style="display:none;">
                            <textarea
                                id="business_description"
                                name="business_description"
                                rows="8"
                                class="sitestaffr-textarea"
                                maxlength="15000"
                                placeholder="<?php esc_attr_e( 'Tell customers about your services, specialties, and what makes you unique...', 'sitestaffr' ); ?>"
                            ></textarea>
                            <p class="sitestaffr-field-helper">
                                <span class="sitestaffr-char-count" id="char-count-wrapper">
                                    <span id="char-count">0</span> / 15000
                                </span>
                            </p>
                        </div>
                    </div>

                    <!-- Completion Buttons -->
                    <div class="sitestaffr-button-group-step">
                        <button type="button" class="sitestaffr-btn-save" id="save-enhancement">
                            <?php esc_html_e( 'Save &amp; Finish', 'sitestaffr' ); ?>
                        </button>
                    </div>

                    <div class="sitestaffr-step-back-row sitestaffr-step-back-row-bottom">
                        <button type="button" class="sitestaffr-step-back-link" id="back-to-step-2">
                            <span class="dashicons dashicons-arrow-left-alt"></span>
                            <?php esc_html_e( 'Back to Plan Selection', 'sitestaffr' ); ?>
                        </button>
                    </div>
                </div><!-- /#wizard-step-3-content -->
            </div><!-- /#wizard-step-3 -->

            <!-- Navigation Buttons (Steps 1 only; Step 2 uses plan cards; Step 3 uses custom buttons) -->
            <div class="sitestaffr-wizard-nav" id="wizard-nav">
                <button type="button" class="sitestaffr-btn-back" id="btn-back" style="display: none;">
                    <span class="dashicons dashicons-arrow-left-alt"></span>
                    <?php esc_html_e( 'Previous', 'sitestaffr' ); ?>
                </button>

                <div class="sitestaffr-nav-right">
                    <button type="button" class="sitestaffr-btn-next" id="btn-next">
                        <?php esc_html_e( 'Next', 'sitestaffr' ); ?>
                        <span class="dashicons dashicons-arrow-right-alt"></span>
                    </button>
                </div>
            </div>
        </form>

        <!-- Loading Overlay -->
        <div class="sitestaffr-loading-overlay" id="loading-overlay" style="display: none;">
            <div class="sitestaffr-spinner"></div>
            <p><?php esc_html_e( 'Saving your settings...', 'sitestaffr' ); ?></p>
        </div>
    </div><!-- /.sitestaffr-wizard-container -->
</div><!-- /.wrap -->

<!-- Wizard JS enqueued via class-sitestaffr-admin.php (setup-wizard.js) -->
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
