<?php
// Buy More Minutes Modal partial.
// Renders current balance context for included + add-on minutes.
if ( ! defined( 'WPINC' ) ) { die; }

$sitestaffr_buy_modal_balance = array(
	'included'  => 0,
	'purchased' => 0,
	'total'     => 0,
);

if ( isset( $included ) || isset( $purchased ) || isset( $total ) ) {
	$sitestaffr_buy_modal_balance['included']  = isset( $included ) ? max( 0, (int) $included ) : 0;
	$sitestaffr_buy_modal_balance['purchased'] = isset( $purchased ) ? max( 0, (int) $purchased ) : 0;
	$sitestaffr_buy_modal_balance['total']     = isset( $total )
		? max( 0, (int) $total )
		: ( $sitestaffr_buy_modal_balance['included'] + $sitestaffr_buy_modal_balance['purchased'] );
} elseif ( class_exists( 'SiteStaffr_Usage_Manager' ) ) {
	$sitestaffr_buy_modal_usage_manager = SiteStaffr_Usage_Manager::get_instance();
	if ( $sitestaffr_buy_modal_usage_manager && method_exists( $sitestaffr_buy_modal_usage_manager, 'get_minutes_balance' ) ) {
		$sitestaffr_live_balance = $sitestaffr_buy_modal_usage_manager->get_minutes_balance();
		if ( is_array( $sitestaffr_live_balance ) ) {
			$sitestaffr_buy_modal_balance['included']  = isset( $sitestaffr_live_balance['included'] ) ? max( 0, (int) $sitestaffr_live_balance['included'] ) : 0;
			$sitestaffr_buy_modal_balance['purchased'] = isset( $sitestaffr_live_balance['purchased'] ) ? max( 0, (int) $sitestaffr_live_balance['purchased'] ) : 0;
			$sitestaffr_buy_modal_balance['total']     = isset( $sitestaffr_live_balance['total'] )
				? max( 0, (int) $sitestaffr_live_balance['total'] )
				: ( $sitestaffr_buy_modal_balance['included'] + $sitestaffr_buy_modal_balance['purchased'] );
		}
	}
}
?>
<div class="sitestaffr-modal-overlay" id="sitestaffr-buy-modal" role="dialog" aria-modal="true" aria-hidden="true" aria-labelledby="sitestaffr-buy-modal-title" style="display: none;">
	<div class="sitestaffr-modal" role="document">
		<div class="sitestaffr-modal-header">
			<h2 id="sitestaffr-buy-modal-title">
				<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
				<?php esc_html_e( 'Buy More Minutes', 'sitestaffr' ); ?>
			</h2>
			<button type="button" class="sitestaffr-modal-close" aria-label="<?php esc_attr_e( 'Close', 'sitestaffr' ); ?>">
				<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
			</button>
		</div>
		<div class="sitestaffr-modal-body">
			<div class="sitestaffr-modal-balance">
				<span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
				<?php
				echo esc_html(
					sprintf(
						// translators: %d: number of minutes remaining.
						__( 'Total minutes remaining: %d.', 'sitestaffr' ),
						$sitestaffr_buy_modal_balance['total']
					)
				);
				?>
			</div>
			<div class="sitestaffr-modal-product">
				<div class="sitestaffr-modal-product-info">
					<span class="sitestaffr-modal-product-name"><?php esc_html_e( 'Add-on Minutes Pack', 'sitestaffr' ); ?></span>
					<span class="sitestaffr-modal-product-detail"><?php esc_html_e( 'Add-on minutes never expire.', 'sitestaffr' ); ?></span>
				</div>
			</div>
			<div class="sitestaffr-modal-stepper-row">
				<label class="sitestaffr-modal-stepper-label" for="sitestaffr-addon-quantity"><?php esc_html_e( 'Quantity', 'sitestaffr' ); ?></label>
				<div class="sitestaffr-modal-stepper">
					<button type="button" class="sitestaffr-stepper-btn sitestaffr-stepper-minus" aria-label="<?php esc_attr_e( 'Decrease quantity', 'sitestaffr' ); ?>" disabled>
						<span class="dashicons dashicons-minus" aria-hidden="true"></span>
					</button>
					<input type="number" id="sitestaffr-addon-quantity" class="sitestaffr-stepper-input" value="1" min="1" max="10" step="1" readonly aria-label="<?php esc_attr_e( 'Number of add-on packs', 'sitestaffr' ); ?>">
					<button type="button" class="sitestaffr-stepper-btn sitestaffr-stepper-plus" aria-label="<?php esc_attr_e( 'Increase quantity', 'sitestaffr' ); ?>">
						<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
					</button>
				</div>
			</div>
			<div class="sitestaffr-modal-summary" aria-live="polite">
				<div class="sitestaffr-modal-summary-line">
					<span class="sitestaffr-modal-summary-minutes" id="sitestaffr-modal-minutes"><?php esc_html_e( '50 minutes', 'sitestaffr' ); ?></span>
					<span class="sitestaffr-modal-summary-price" id="sitestaffr-modal-price"><?php esc_html_e( '$10', 'sitestaffr' ); ?></span>
				</div>
			</div>
		</div>
		<div class="sitestaffr-modal-footer">
			<button type="button" class="button sitestaffr-modal-cancel"><?php esc_html_e( 'Cancel', 'sitestaffr' ); ?></button>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" target="_blank" id="sitestaffr-buy-form">
				<input type="hidden" name="action" value="sitestaffr_billing_checkout">
				<input type="hidden" name="checkout_type" value="addon">
				<input type="hidden" name="addon_type" value="minutes_50">
				<input type="hidden" name="quantity" value="1" id="sitestaffr-buy-quantity">
				<?php wp_nonce_field( 'sitestaffr_billing_checkout' ); ?>
				<button type="submit" class="button button-primary sitestaffr-modal-confirm">
					<span class="dashicons dashicons-cart" aria-hidden="true"></span>
					<?php esc_html_e( 'Confirm Purchase', 'sitestaffr' ); ?>
				</button>
			</form>
		</div>
	</div>
</div>
