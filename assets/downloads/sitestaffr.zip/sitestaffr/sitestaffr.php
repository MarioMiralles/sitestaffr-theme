<?php
/**
 * Plugin Name: SiteStaffr
 * Plugin URI: https://sitestaffr.com
 * Description: AI-powered voice agent widget for WordPress. Provides browser-based live conversations, transcript history, and follow-up management through an intuitive admin interface.
 * Version: 1.19.33
 * Author: SiteStaffr
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: sitestaffr
 * Domain Path: /languages
 * Requires at least: 6.2
 * Requires PHP: 7.4
 *
 * @package SiteStaffr
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound,WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound

/**
 * Current plugin version.
 */
define( 'SITESTAFFR_VERSION', '1.19.33' );
define( 'SITESTAFFR_DAILY_GEN_LIMIT', 10 );

/**
 * Plugin directory path.
 */
define( 'SITESTAFFR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Dev-mode: auto-enabled on local environments (localhost, 127.0.0.1, .local).
 * Can also be explicitly set in wp-config.php.
 */
if ( ! defined( 'SITESTAFFR_DEV_MODE' ) ) {
	$__host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	define(
		'SITESTAFFR_DEV_MODE',
		in_array( $__host, array( 'localhost', '127.0.0.1', '::1' ), true )
		|| substr( $__host, -6 ) === '.local'
		|| substr( $__host, -5 ) === '.test'
	);
	unset( $__host );
}

/**
 * Plugin directory URL.
 */
define( 'SITESTAFFR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Middleware URL for voice session API and site registration.
 *
 * Loaded from database (set during plugin activation). Falls back to default
 * if not yet configured. Storing in the database avoids exposing infrastructure
 * details in source code and allows URL changes without a plugin update.
 *
 * @since 0.11.59
 */
$_sitestaffr_mw_url = get_option( 'sitestaffr_middleware_url', '' );
if ( empty( $_sitestaffr_mw_url ) ) {
	$_sitestaffr_mw_url = get_option( 'phoneease_middleware_url', 'https://phoneease-middleware-375589245036.us-central1.run.app' );
}
// Fix bad URL from early rebrand (Cloud Run service is still phoneease-middleware).
$_sitestaffr_mw_url = str_replace( 'sitestaffr-middleware-', 'phoneease-middleware-', $_sitestaffr_mw_url );
// TEMP: Force staging MW for staging site (remove before merge).
if ( false !== strpos( get_site_url(), 'staging.sitestaffr.com' ) ) {
	$_sitestaffr_mw_url = 'https://sitestaffr-staging-mw-375589245036.us-central1.run.app';
	// Persist so it survives page loads without hitting this check every time.
	update_option( 'sitestaffr_middleware_url', $_sitestaffr_mw_url, false );
}
define( 'SITESTAFFR_MIDDLEWARE_URL', $_sitestaffr_mw_url );
unset( $_sitestaffr_mw_url );

/**
 * Billing cutover flag.
 *
 * Phase 5+: when true, read billing display state from middleware-backed cache.
 * Keep false until cache sync validation is complete.
 *
 * @since 0.14.10
 */
if ( ! defined( 'SITESTAFFR_BILLING_CUTOVER' ) ) {
	define( 'SITESTAFFR_BILLING_CUTOVER', true );
}

/**
 * The code that runs during plugin activation.
 */
function activate_sitestaffr() {
    require_once SITESTAFFR_PLUGIN_DIR . 'includes/class-sitestaffr-activator.php';
    require_once SITESTAFFR_PLUGIN_DIR . 'includes/class-sitestaffr-auth-token.php';
    require_once SITESTAFFR_PLUGIN_DIR . 'includes/class-sitestaffr-site-registration.php';
    SiteStaffr_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_sitestaffr() {
    require_once SITESTAFFR_PLUGIN_DIR . 'includes/class-sitestaffr-deactivator.php';
    SiteStaffr_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_sitestaffr' );
register_deactivation_hook( __FILE__, 'deactivate_sitestaffr' );

if ( is_admin() ) {
    require_once SITESTAFFR_PLUGIN_DIR . 'includes/class-sitestaffr-deactivator.php';
    SiteStaffr_Deactivator::register_admin_warning_hooks();
}

/**
 * Centralized logger with redaction + environment gating.
 */
require SITESTAFFR_PLUGIN_DIR . 'includes/class-sitestaffr-logger.php';

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require SITESTAFFR_PLUGIN_DIR . 'includes/class-sitestaffr.php';

/**
 * Begins execution of the plugin.
 *
 * @since 1.0.0
 */
function run_sitestaffr() {
    $plugin = new SiteStaffr();
    $plugin->run();
}

run_sitestaffr();

// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound,WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound
